<?php

class dbOperations
{

    private $con;
    private $con_status = false;

    public function __construct()
    { // create constructor

        require_once dirname(__FILE__) . '/dbConnect.php'; // call dbConnect class

        $db = new dbConnect;
        $this->con = $db->connect();
        if ($this->con != null) {
            $this->con_status = true;
        } else { $this->con_status = false;}

    }

    // to Signup User
    public function createUser($name, $email, $password, $address, $phone, $location)
    {

        if (!$this->isEmailExist($email)) {
            $output = $this->con->prepare("insert into users(name,email,password,address,phone,location) values(?,?,?,?,?,?)");
            $output->bind_param("ssssss", $name, $email, $password, $address, $phone, $location); // binding parameters with qurey.
            //sss is data no of variables

            if ($output->execute()) {
                $output = $this->con->prepare("INSERT INTO `user_points`( `user_id`, `category_id`, `points`) VALUES ((SELECT user_id from users where email = ?),1,0)");
                $output->bind_param("s", $email); // set XPRS points 0.
                if ($output->execute()) {
                    $output = $this->con->prepare("INSERT INTO `user_points`( `user_id`, `category_id`, `points`) VALUES ((SELECT user_id from users where email = ?),2,0)");
                    $output->bind_param("s", $email); // set Frozen 0.
                    if ($output->execute()) {
                        return USER_CREATED;
                    }
                }
            } else {
                return USER_FAILURE;
            }
        }
        return USER_EXISTS;
    }

    // check is email already exists
    private function isEmailExist($email)
    {

        $output = $this->con->prepare("select user_id from users where email = ?");
        $output->bind_param("s", $email);
        $output->execute();
        $output->store_result();

        return $output->num_rows > 0;
    }

    // to login user
    public function userLogin($email, $password)
    {
        if ($this->isEmailExist($email)) {

            $hashed_password = $this->getUsersPasswordByEmail($email);
            if (strcmp($password, $hashed_password) == 0) {
                $account_status = $this->getUsersAcountStatus($email);
                if ($account_status == 1) {
                    return USER_AUTHENTICATED;
                } else {
                    return USER_NOT_ALLOWED;
                }
            } else {
                return INVALID_PASSWORD;
            }

        } else {
            return USER_NOT_FOUND;
        }
    }

    // to get user password by email
    private function getUsersPasswordByEmail($email)
    {
        $output = $this->con->prepare("select password from users where email = ?");
        $output->bind_param("s", $email);
        $output->execute();
        $output->bind_result($password);
        $output->fetch();
        return $password;
    }

    // to check if user allowed to use app
    private function getUsersAcountStatus($email)
    {
        $output = $this->con->prepare("select active from users where email = ?");
        $output->bind_param("s", $email);
        $output->execute();
        $output->bind_result($status);
        $output->fetch();
        return $status;
    }

    // to get user info after login
    public function getUserInfoByEmail($email)
    {
        $output = $this->con->prepare("select user_id,email,name,address,phone,active from users where email = ?");
        $output->bind_param("s", $email);
        $output->execute();
        $output->bind_result($id, $email, $name, $address, $phone, $active);
        $output->fetch();
        $user = array();
        $user['id'] = $id;
        $user['email'] = $email;
        $user['name'] = $name;
        $user['address'] = $address;
        $user['phone'] = $phone;
        $user['active'] = $active;

        return $user;
    }

    // get all users in db
    public function getAllUsers()
    {
        $output = $this->con->prepare("select id,email,name from users;");
        $output->execute();
        $output->bind_result($id, $email, $name);

        $users = array();

        while ($output->fetch()) { // fetching data until no row remain
            $user = array();
            $user['id'] = $id;
            $user['email'] = $email;
            $user['name'] = $name;

            array_push($users, $user); // puch user array into users array

        }
        return $users;
    }

    //update user email and name by id
    public function updateUserInfo($name, $password, $address, $phone, $email)
    {
        if ($password == '') {
            $output = $this->con->prepare("update users set name = ?, address =?, phone =? where email =?");
            $output->bind_param("ssss", $name, $address, $phone, $email);
            if ($output->execute()) {
                return true;
            } else {
                return false;
            }
        } else {
            $output = $this->con->prepare("update users set name = ?, password =?, address =?, phone =? where email =?");
            $output->bind_param("sssss", $name, $password, $address, $phone, $email);
            if ($output->execute()) {
                return true;
            } else {
                return false;
            }
        }
    }

    // update password
    public function updateUserPassword($currentPassword, $newPassword, $email)
    {
        $hashed_password = $this->getUsersPasswordByEmail($email);

        if (strcmp($currentPassword, $hashed_password) == 0) {

            //$hashed_password = password_hash($newPassword,PASSWORD_DEFAULT); //encrypt new password

            $output = $this->con->prepare("update users set password = ? where email = ?");
            $output->bind_param("ss", $newPassword, $email);
            if ($output->execute()) {
                return PASSWORD_CHANGED;
            } else {
                return PASSWORD_NOT_CHANGED;
            }

        } else {
            return PASSWORD_DO_NOT_MATCH;
        }
    }

    // reset password
    public function resetUserPassword($newPassword, $email)
    {
        if ($this->isEmailExist($email)) {

            // $hashed_password = password_hash($newPassword,PASSWORD_DEFAULT); //encrypt new password

            $output = $this->con->prepare("update users set password = ? where email = ?");
            $output->bind_param("ss", $newPassword, $email);
            if ($output->execute()) {
                return PASSWORD_CHANGED;
            } else {
                return PASSWORD_NOT_CHANGED;
            }

        } else {
            return USER_NOT_FOUND;
        }
    }

    public function getCities()
    {
        $output = $this->con->prepare("SELECT * FROM cities");
        $output->execute();
        $output->bind_result($id, $code, $name, $delivery_time, $status, $date);

        $cities = array();
        while ($output->fetch()) {
            $city = array();
            $city['id'] = $id;
            $city['code'] = $code;
            $city['name'] = $name;
            $city['delivery_timings'] = $delivery_time;
            $city['status'] = $status;

            array_push($cities, $city);
        }
        return $cities;
    }

    public function getAllData($city_id)
    {
        $data = $this->getCityProducts($city_id);
        return $data;
    }

    private function getCityProducts($city_id)
    {
        $output = $this->con->prepare("SELECT * FROM cities where cityid = ?");
        $output->bind_param("i", $city_id);
        $output->execute();
        $output->store_result();
        $output->bind_result($id, $code, $name, $delivery_time, $status, $date);

        $cities = array();
        while ($output->fetch()) {
            $city = array();
            $city['id'] = $id;
            $city['code'] = $code;
            $city['name'] = $name;
            $city['delivery_timings'] = $delivery_time;
            $city['status'] = $status;

            $city['categories'] = $this->getCategories($id);

            array_push($cities, $city);
        }
        return $cities;
    }

    private function getCategories($city_id)
    {

        $output = $this->con->prepare("SELECT cid, category, cimg FROM category;");
        $output->execute();
        $output->store_result();
        $output->bind_result($id, $name, $cig);

        $categories = array();
        while ($output->fetch()) {
            $category = array();
            $category['id'] = $id;
            $category['name'] = $name;
            $category['image'] = $cig;

            $category['products'] = $this->getProducts($id, $city_id);

            array_push($categories, $category);
        }
        $output->close();
        return $categories;
    }

    private function getProducts($categories_id, $city_id)
    {
        $output = $this->con->prepare("SELECT pid, products.cid, sku, pname, weight, weight_unit, currency, instock, description, image
                                        FROM products LEFT JOIN category ON products.cid = category.cid WHERE products.cid = ?");
        $output->bind_param("i", $categories_id);
        $output->execute();
        $output->store_result();
        $output->bind_result($id, $cid, $sku, $name, $weight, $weight_unit, $currency, $stock, $desc, $img);

        $products = array();
        while ($output->fetch()) {
            $product = array();
            $product['id'] = $id;
            $product['cat_id'] = $cid;
            $product['name'] = $name;
            $product['price'] = $this->getProductPrice($id, $city_id);
            $product['weight'] = $weight;
            $product['weight_unit'] = $weight_unit;
            $product['stock'] = $stock;
            $product['desc'] = strip_tags(preg_replace('!\\r?\\n!', "", $desc));
            $product['img'] = $this->getProductImg($id);
            $product['currency'] = $currency;

            array_push($products, $product);
        }
        $output->close();
        return $products;
    }

    private function getProductPrice($pid, $cid)
    {
        $output = $this->con->prepare("SELECT price FROM product_prices WHERE pid = ? AND cityid = ?;");
        $output->bind_param("ii", $pid, $cid);
        $output->execute();
        // $output->store_result();
        $output->bind_result($price);
        $output->fetch();
        $output->close();
        return $price;
    }

    private function getProductImg($pid)
    {
        $output = $this->con->prepare("SELECT largeimage FROM images WHERE pid = ?;");
        $output->bind_param("i", $pid);
        $output->execute();
        // $output->store_result();
        $output->bind_result($img);
        $output->fetch();
        $output->close();
        return PRODUCT_IMG_PATH . $img;
    }

    public function getBannerImgs()
    {
        $output = $this->con->prepare("SELECT mbanner FROM banners where bstatus = 0");
        $output->execute();
        $output->bind_result($img);

        $banners = array();
        while ($output->fetch()) {
            $banner = array();
            $banner['img'] = BANNER_IMG_PATH . $img;

            array_push($banners, $banner);
        }
        return $banners;
    }

    public function placeOrder($name, $email, $mobile, $address, $comment, $products, $total_quantity, $total_price)
    {
        $output = $this->con->prepare("INSERT INTO orders (otype, totalqty, totalPrice, contactPerson, oemail,
                                        omobile, oaddress, ocomments) values (1,?,?,?,?,?,?,?) ");
        $output->bind_param("iisssss", $total_quantity, $total_price, $name, $email, $mobile, $address, $comment);

        if ($output->execute()) {
            $order_id = mysqli_insert_id($this->con);
            for ($j = 0; $j < count($products['products']); $j++) { 
                $product_id = $products['products'][$j]['id'];
                $quantity = $products['products'][$j]['quantity'];
                $unit_price = $products['products'][$j]['unitPrice'];
                $prod_total_price = $products['products'][$j]['totalPrice'];

                $current_timestamp = $this->getCurrentTime();
                
                $output = $this->con->prepare("INSERT INTO cart (oid, pid, qty, unitprice, totalprice, cartdate)
                                                values (?,?,?,?,?,?) ");
                $output->bind_param("iiiiis", $order_id, $product_id, $quantity, $unit_price, $prod_total_price, $current_timestamp);

                if (!$output->execute()) {
                    return FAILED;
                }
            }
        } else {
            return FAILED;
        }
        return $order_id;
    }


    public function getCurrentTime()
    {
        date_default_timezone_set("Asia/Karachi");
        return date('Y-m-d H:i:s');
    }

    public function __destruct()
    {
        if ($this->con_status) {
            if ($this->con->close()) {
                $this->con_status = false;
            } else {
                return false;
            }
        }
    }
}
