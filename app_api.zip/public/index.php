<?php
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

require '../vendor/autoload.php';
require '../include/dbConnect.php';
require '../include/dbOperations.php';
require '../include/constant.php';
require '../php-send-mail/mail_function.php';
require '../php-send-mail/order_email_template.php';

$app = new \Slim\App([
    'settings' => [
        'displayErrorDetails' => true,
    ],
]);

//*** For Api security from "https://github.com/tuupola/slim-basic-auth"
/*$app->add(new Tuupola\Middleware\HttpBasicAuthentication([
"secure" =>true,
"users" => [
"admin" => "admin", // api access username and password
]
]));*/

// api call to test connection
$app->get('/hello', function (Request $request, Response $response) {

    $db = new dbConnect;

    if ($db->connect() != null) {
        echo 'connection successful for SimplySufi_XPRS DB';
        $db = new dbOperations;
    }
    return $response;
});

//  api call to create user account
$app->post('/createuser', function (Request $request, Response $response) {

    $request_data = $request->getParsedBody();

    $name = $request_data['name'];
    $email = $request_data['email'];
    $password = $request_data['password'];
    $address = $request_data['address'];
    $phone = $request_data['phone'];
    $location = $request_data['location'];

    // $hash_password = password_hash($password,PASSWORD_DEFAULT);

    $db = new dbOperations;

    $result = $db->createUser($name, $email, $password, $address, $phone, $location);

    if ($result == USER_CREATED) {

        // display message in response
        $message = array();
        $message['error'] = false;
        $message['message'] = 'User created';
        $response->write(json_encode($message));
        return $response->withHeader('Content-type', 'application/json')->withStatus(201);

    } else if ($result == USER_FAILURE) {

        // display message in response
        $message = array();
        $message['error'] = true;
        $message['message'] = 'Error Occured';
        $response->write(json_encode($message));
        return $response->withHeader('Content-type', 'application/json')->withStatus(422);
    } else if ($result == USER_EXISTS) {

        // display message in response
        $message = array();
        $message['error'] = true;
        $message['message'] = 'User already exists';
        $response->write(json_encode($message));
        return $response->withHeader('Content-type', 'application/json')->withStatus(422);
    }
});

//  api call to login user
$app->post('/userlogin', function (Request $request, Response $response) {

    $request_data = $request->getParsedBody();

    $email = $request_data['email'];
    $password = $request_data['password'];

    $db = new dbOperations;

    $result = $db->userLogin($email, $password);

    if ($result == USER_AUTHENTICATED) {
        $user = $db->getUserInfoByEmail($email);

        $response_data = array();
        $response_data['error'] = false;
        $response_data['message'] = 'Login Successful';
        $response_data['user'] = $user;
        $response->write(json_encode($response_data));
        return $response->withHeader('Content-type', 'application/json')->withStatus(200);
    } else if ($result == INVALID_PASSWORD) {
        $response_data = array();
        $response_data['error'] = true;
        $response_data['message'] = 'Invalid Password';
        // $response_data['user'] = $user;
        $response->write(json_encode($response_data));
        return $response->withHeader('Content-type', 'application/json')->withStatus(200);
    } else if ($result == USER_NOT_FOUND) {
        $response_data = array();
        $response_data['error'] = true;
        $response_data['message'] = 'User not exist';
        //$response_data['user'] = $user;
        $response->write(json_encode($response_data));
        return $response->withHeader('Content-type', 'application/json')->withStatus(200);
    } else if ($result == USER_NOT_ALLOWED) {
        $response_data = array();
        $response_data['error'] = true;
        $response_data['message'] = 'You are not authenticated to use this app. Kindly contact support.';
        //$response_data['user'] = $user;
        $response->write(json_encode($response_data));
        return $response->withHeader('Content-type', 'application/json')->withStatus(200);
    }
});

//  api call to get user info by email
$app->get('/getUserInfo/{email}', function (Request $request, Response $response, array $arg) {

    $email = $arg['email'];
    $db = new dbOperations;
    $user = $db->getUserInfoByEmail($email);
    $response_data = array();

    $response_data['user'] = $user;

    $response->write(json_encode($response_data));
    return $response->withHeader('Content-type', 'application/json')->withStatus(200);
});

//  api call to update user info
$app->post('/updateuserinfo', function (Request $request, Response $response) {

    $request_data = $request->getParsedBody();
    $name = $request_data['name'];
    $password = $request_data['password'];
    $address = $request_data['address'];
    $phone = $request_data['phone'];
    $email = $request_data['email'];

    $db = new dbOperations;

    if ($name != null && $address != null && $phone != null && $email != null) {

        if ($db->updateUserInfo($name, $password, $address, $phone, $email)) {
            $response_data = array();
            $response_data['error'] = false;
            $response_data['message'] = 'Update user Successful';
            $user = $db->getUserInfoByEmail($email);
            $response_data['user'] = $user;

            $response->write(json_encode($response_data));
            return $response->withHeader('Content-type', 'application/json')->withStatus(200);
        } else {
            $response_data = array();
            $response_data['error'] = true;
            $response_data['message'] = 'Try again';
            $user = $db->getUserInfoByEmail($email);
            $response_data['user'] = $user;

            $response->write(json_encode($response_data));
            return $response->withHeader('Content-type', 'application/json')->withStatus(200);
        }
    } else {

        $response_data['error'] = true;
        $response_data['message'] = 'Fields Cant be empty ';
        $response->write(json_encode($response_data));
        return $response->withHeader('Content-type', 'application/json')->withStatus(200);
    }
    return $response->withHeader('Content-type', 'application/json')->withStatus(200);

});

//  api call to delete user account by email
$app->delete('/deleteuseraccount', function (Request $request, Response $response) {

    $request_data = $request->getParsedBody();
    $response_data = array();
    $email = $request_data['email'];

    $db = new dbOperations;

    $result = $db->deleteUserAccount($email);

    if ($result == ACCOUNT_DELETED) {
        $response_data['error'] = false;
        $response_data['message'] = 'Account has deleted';
    } else if ($result == ERROR_OCCUR) {
        $response_data['error'] = true;
        $response_data['message'] = 'Try again';
    } else if ($result == ACCOUNT_NOT_EXIST) {
        $response_data['error'] = true;
        $response_data['message'] = 'Account not exist';
    }

    $response->write(json_encode($response_data));
    return $response->withHeader('Content-type', 'application/json')->withStatus(200);
});

//  api call to reset forgot password
$app->post('/resetUserPassword', function (Request $request, Response $response) {

    $request_data = $request->getParsedBody();

    $newpassword = $request_data['newpassword'];
    $email = $request_data['email'];

    $db = new dbOperations;

    $result = $db->resetUserPassword($newpassword, $email);

    if ($result == PASSWORD_CHANGED) {

        $response_data = array();
        $response_data['error'] = false;
        $response_data['message'] = 'Password Changed';
        $response->write(json_encode($response_data));
        return $response->withHeader('Content-type', 'application/json')->withStatus(200);

    } else if (USER_NOT_FOUND) {
        $response_data = array();
        $response_data['error'] = true;
        $response_data['message'] = 'Account not Exist on that Email address';
        $response->write(json_encode($response_data));
        return $response->withHeader('Content-type', 'application/json')->withStatus(200);
    } else if (PASSWORD_NOT_CHANGED) {
        $response_data = array();
        $response_data['error'] = true;
        $response_data['message'] = 'Try again later';
        $response->write(json_encode($response_data));
        return $response->withHeader('Content-type', 'application/json')->withStatus(200);
    }

    return $response->withHeader('Content-type', 'application/json')->withStatus(422);
});

$app->get('/getBannerImgs', function (Request $request, Response $response) {

    $db = new dbOperations;
    $banner = $db->getBannerImgs();
    $response_data = array();

    $response_data['banner'] = $banner;

    $response->write(json_encode($response_data));
    return $response->withHeader('Content-type', 'application/json')->withStatus(200);
});

$app->get('/getCities', function (Request $request, Response $response) {

    $db = new dbOperations;
    $cities = $db->getCities();
    $response_data = array();

    $response_data['cities'] = $cities;

    $response->write(json_encode($response_data));
    return $response->withHeader('Content-type', 'application/json')->withStatus(200);
});

// api call to get all products data by city Id
$app->get('/getAllData/{city_id}', function (Request $request, Response $response, array $arg) {

    $city_id = $arg['city_id'];
    $db = new dbOperations;
    $data = $db->getAllData($city_id);
    $response_data = array();

    $response_data['cities'] = $data;

    $response->write(json_encode($response_data));
    return $response->withHeader('Content-type', 'application/json')->withStatus(200);
});

$app->post('/placeOrder', function (Request $request, Response $response) {

    $request_data = $request->getParsedBody();
    // print_r(count($request_data));

    if (!isEmptyParameters($request_data, 8)) {

        $name = $request_data['name'];
        $email = $request_data['email'];
        $mobile = $request_data['mobile'];
        $city = $request_data['city'];
        $address = $request_data['address'];
        $comment = $request_data['comment'];
        // $products = $request_data['cart'];
        $products = '{
            "products": [
                {
                    "id": 1,
                    "title": "Beef Burger",
                    "img": "48357681.jpg",
                    "quantity": 2,
                    "weight": "1",
                    "weight_unit": "Kg",
                    "unitPrice": 250,
                    "totalPrice": 500
                },
                {
                    "id": 1,
                    "title": "Chapli Deal",
                    "img": "71467395.jpeg",
                    "quantity": 2,
                    "weight": "1",
                    "weight_unit": "Pc",
                    "unitPrice": 300,
                    "totalPrice": 600
                }
            ]
        }';

        $total_quantity = $request_data['total_quantity'];
        $total_price = $request_data['total_bill'];

        $products_data = json_decode($products,true);
        // echo $products_data['products'][0]['title'];
        // return;

        $request_data['cart'] = $products_data;

        $db = new dbOperations;

       $result = $db->placeOrder($name, $email, $mobile, $address, $comment, $products_data, $total_quantity, $total_price);
        
        if ($result == 603) {
            $response_data['error'] = true;
            $response_data['message'] = "Some Error Occur!";
        } elseif($result != '') {
            $request_data['order_id'] = $result;
            $request_data['datetime'] = $db->getCurrentTime();
            $order_email = get_html_code($request_data);

            if(sendOrderMail($email,$order_email)){
                $response_data['error'] = false;
                $response_data['message'] = "Your order is placed successfully!";
            }else{
                $response_data['error'] = true;
                $response_data['message'] = "Failed to send Email!";
            }
        }
    } else {
        $response_data['error'] = true;
        $response_data['message'] = "Some fields are missing or empty!";
    }

    $response->write(json_encode($response_data));
    return $response->withHeader('Content-type', 'application/json')->withStatus(200);

});


function isEmptyParameters($request_data, $no_of_params)
{
    if(count($request_data) < $no_of_params ){
        return true;
    }
    foreach ($request_data as $data) {
        if($data == null)
        return true;
    }
    return false;
}


$app->run();
