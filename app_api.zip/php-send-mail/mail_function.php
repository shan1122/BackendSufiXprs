<?php	
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;



	function sendOrderMail($email,$message) {
		
		require('phpmailer/src/PHPMailer.php');
		require('phpmailer/src/SMTP.php');
		require('phpmailer/src/Exception.php');

	
		$message_body =  $message;
		$mail = new PHPMailer();
		$mail->IsSMTP();
		$mail->SMTPDebug = 1;
		$mail->SMTPAuth = TRUE;
		$mail->SMTPSecure = 'ssl'; // tls or ssl
		$mail->Port     = "465";
		$mail->Username = "smarttechdevelopers00@gmail.com";
		$mail->Password = "177478914a.G.a";
		$mail->Host     = "ssl://smtp.gmail.com";
		$mail->Mailer   = "smtp";
		$mail->SetFrom("smarttechdevelopers00@gmail.com", "SIMPLY SUFI XPRS");
		$mail->addAddress($email); // user email address
		$mail->addBCC("m.awais580@yahoo.com"); // simplysufi email address
		$mail->Subject = "SimplySufi XPRS - Your order is received successfully";
		$mail->MsgHTML($message_body);
		$mail->IsHTML(true);		
		try {
			    if($mail->send()){
					return true;
				}else{
					return false;
				}
			    
			} catch (Exception $e) {
			    echo "Mailer Error: " . $mail->ErrorInfo;
			}

}
?>